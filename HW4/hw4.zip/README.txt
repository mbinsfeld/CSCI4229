Matt Binsfeld
Homework 4
CSCI 4229

This is a scene with several houses scaled and placed around a scene.

Key bindings:
m          Toggle between perspective and orthogonal
+/-        Changes field of view for perspective
arrows     Change view angle
w/s        Zoom in and out
0          Reset view angle
ESC        Exit

First Person Controls:
Rotate a/d
Move w/s

This took me about 3 hours.