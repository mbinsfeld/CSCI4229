Matt Binsfeld
Homework 5
CSCI 4229

This is a scene with several houses scaled and placed around a scene and an orbiting light.


 *  Key bindings:
 *  'p' to switch modes (projections)
 *  'x' to toggle axes
 *  '0' snaps angles to 0,0
 *  arrows to rotate the world
 *  PgUp/PgDn zooms in/out
 *  +/- changes field of view of perspective
 *  F1 toggles smooth/flat shading
 *  F2 toggles local viewer mode
 *  F3 toggles light distance (1/5)
 *  F8 change ball increment
 *  F9 invert bottom normal
 *  'l' toggles lighting
 *  a/A decrease/increase ambient light
 *  d/D decrease/increase diffuse light
 *  s/S decrease/increase specular light
 *  e/E decrease/increase emitted light
 *  n/N decrease/increase shininess
 *  m  toggles light movement
 *  [] lower/rise light

This took me 4 hours.